<div class="sidebar-menu">
	<header class="logo1">
		<a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a>
	</header>
	<div style="border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
	<div class="menu">
		<ul id="menu">
			<li><a href="dashboard.php"><i class="fa fa-tachometer"></i> <span>Dashboard</span>
					<div class="clearfix"></div>
				</a></li>

			<li id="menu-academico"><a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span> Add</span> <span class="fa fa-angle-right" style="float: right"></span>
					<div class="clearfix"></div>
				</a>
				<ul id="menu-academico-sub">
					<li id="menu-academico-avaliacoes"><a href="add-gallery.php">Gallery</a></li>
					<li id="menu-academico-avaliacoes"><a href="add-alumni.php">Alumni</a></li>
					<li id="menu-academico-avaliacoes"><a href="add-lasteventwinner.php">Evnent Winner</a></li>
				</ul>
			</li>
			<li id="menu-academico"><a href="manage-lasteventwinner.php"><i class="fa fa-users" aria-hidden="true"></i><span>Last Event Winner</span>
					<div class="clearfix"></div>
				</a></li>

			<li><a href="manage-alumni.php"><i class="fa fa-list" aria-hidden="true"></i> <span>Manage Alumni</span>
					<div class="clearfix"></div>
				</a></li>
			<!-- <li><a href="manageissues.php"><i class="fa fa-table"></i>  <span>Manage Issues</span><div class="clearfix"></div></a></li> -->
			<li><a href="manage-members.php"><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Manage Members</span>
					<div class="clearfix"></div>
				</a></li>
			<li><a href="manage-contacts.php"><i class="fa fa-file-text-o" aria-hidden="true"></i> <span>Manage Contact</span>
					<div class="clearfix"></div>
				</a></li>


		</ul>
	</div>
</div>