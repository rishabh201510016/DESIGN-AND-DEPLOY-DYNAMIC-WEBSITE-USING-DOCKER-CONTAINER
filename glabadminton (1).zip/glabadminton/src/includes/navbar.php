<!-- loader  -->
<!-- <div class="loader_bg">
        <div class="loader"><img src="images/loading.gif" alt="#" /></div>
    </div> -->
<!-- end loader -->
<!-- header -->
<header>
    <!-- header inner -->
    <div class="header">

        <div class="container">
            <div class="row">
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                    <div class="full">
                        <div class="center-desk">
                            <div class="logo">
                                <a href="index.html"><img src="images\logo.jpg" alt="#"></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                    <div class="menu-area">
                        <div class="limit-box">
                            <nav class="main-menu">
                                <ul class="menu-area-main">
                                    <li class="active"> <a href="index.php">Home</a> </li>
                                    <li><a href="gallery.php">Gallery</a></li>
                                    <li><a href="joinclub.php">Join Club</a></li>
                                    <li><a target="blank" href="https://docs.google.com/spreadsheets/d/16mDMzzlz7LKm_40KkWPV38faNNwi_AcE/edit?usp=sharing&ouid=109690202028189077372&rtpof=true&sd=true">Attandence</a></li>
                                    <li><a href="contact.php">Contact Us</a></li>
                                    <!-- <li><a href="contact.html">Contact Us</a></li> -->
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 offset-md-6">
                    <div class="location_icon_bottum" style="color:black">
                        <ul>
                            <li><img src="icon/call.png" /> <a href="tel:9926215890" style="color:white;"> (+91)9926215890</a></li>
                            <li>Coach Sir </li>
                            <li>Mr. Amit Sharma </li>
                            <!-- <li><img src="icon/email.png" />coach.badminton@gla.ac.in</li> -->
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- end header inner -->
</header>
<!-- end header -->